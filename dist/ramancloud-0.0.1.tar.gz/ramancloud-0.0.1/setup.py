from setuptools import setup

setup(
    name='ramancloud',
    version='0.0.1',
)
